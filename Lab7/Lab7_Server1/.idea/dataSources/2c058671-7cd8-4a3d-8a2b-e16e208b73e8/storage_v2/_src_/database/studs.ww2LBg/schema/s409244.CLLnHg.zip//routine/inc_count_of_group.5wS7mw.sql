create function inc_count_of_group() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE Facultet SET count_of_group=count_of_group+1 WHERE id = NEW.Facultet_id;
  RETURN NEW;
END;
$$;

alter function inc_count_of_group() owner to s409244;

