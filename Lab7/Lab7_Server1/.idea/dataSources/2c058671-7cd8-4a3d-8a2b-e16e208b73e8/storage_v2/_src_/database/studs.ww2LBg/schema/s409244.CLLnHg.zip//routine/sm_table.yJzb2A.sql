create function sm_table()
    returns TABLE(name text, description text)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY
  SELECT Monster.name, Student.description FROM Monster JOIN Student ON Monster.id=Student.monster_id;
END;
$$;

alter function sm_table() owner to s409244;

