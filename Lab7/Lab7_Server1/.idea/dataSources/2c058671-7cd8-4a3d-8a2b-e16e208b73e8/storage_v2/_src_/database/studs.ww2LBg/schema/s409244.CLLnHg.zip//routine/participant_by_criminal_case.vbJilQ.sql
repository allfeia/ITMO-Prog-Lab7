create function participant_by_criminal_case(caseid integer) returns void
    language sql
as
$$SELECT * FROM participant WHERE criminal_case_id = CaseId;$$;

alter function participant_by_criminal_case(integer) owner to s409244;

