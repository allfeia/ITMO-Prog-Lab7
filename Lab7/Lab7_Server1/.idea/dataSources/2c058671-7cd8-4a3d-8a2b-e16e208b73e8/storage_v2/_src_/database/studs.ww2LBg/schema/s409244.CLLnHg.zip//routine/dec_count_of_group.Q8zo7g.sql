create function dec_count_of_group() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE Facultet SET count_of_group=count_of_group-1 WHERE Facultet.id = OLD.Facultet_id;
  RETURN OLD;
END;
$$;

alter function dec_count_of_group() owner to s409244;

