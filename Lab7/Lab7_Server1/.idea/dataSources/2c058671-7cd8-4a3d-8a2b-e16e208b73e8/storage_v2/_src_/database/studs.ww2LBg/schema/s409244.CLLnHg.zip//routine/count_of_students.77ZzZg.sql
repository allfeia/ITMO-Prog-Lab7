create function count_of_students() returns integer
    language plpgsql
as
$$
DECLARE count_of_students INTEGER;
BEGIN 
  SELECT COUNT(*) INTO count_of_students FROM Student;
  RETURN count_of_students;
END;
$$;

alter function count_of_students() owner to s409244;

